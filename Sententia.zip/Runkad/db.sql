CREATE DATABASE runkad;
USE runkad;
CREATE TABLE history (
     id MEDIUMINT NOT NULL AUTO_INCREMENT,
     PlayerOneName CHAR(30),
     PlayerOneScore INT(4),
     PlayerTwoName CHAR(30),
     PlayerTwoScore INT(4),
     WinnerName CHAR(30),
     PRIMARY KEY (id)
);