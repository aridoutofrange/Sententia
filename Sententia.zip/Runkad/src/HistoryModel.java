public class HistoryModel extends Model {
    public String tableName = "history";

    public int id;
    public String playerOneName;
    public int playerOneScore;
    public String playerTwoName;
    public int playerTwoScore;
    public String winnerName;

}
