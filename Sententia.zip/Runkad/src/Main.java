import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.util.Random;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JComponent;

import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.KeyStroke;
import java.awt.Color;

public class Main extends JFrame {
	private JPanel contentPane;
	private final JLabel lblBoard = new JLabel("New label");
	private JLabel lblDimage;
	private JLabel lblP1;
	private JButton btnDice;
	private JLabel lblPlayerName;
	private JLabel p1score;
	private JLabel lblP2;
	private JLabel p2score;
	private JButton btnRestart;
    private int winingPosition=0;
	private JLabel p1,p2;

	private int player=1;    
	private int[] playerposition= new int[4]; 
	private int point;
	private JLabel lblPlayer;
	private JLabel p1btn;
	private JLabel label;
	private int chokka=0;

	public static void main(String[] args) {                    //ekhane dhukar drkr nai :/
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void Dice(){
		Random rn = new Random();

		point = rn.nextInt(6)+1;

		String dice = String.valueOf(point);
		String location = "/Image/dice "+dice+".jpg";
		lblDimage.setIcon(new ImageIcon(Main.class.getResource(location)));  
		playerposition[player-1] = playerposition[player-1] + point;
		if(playerposition[player-1]>100){
			System.out.println("move back");
			playerposition[player-1] = 100 - (playerposition[player-1]-100);
		}
		System.out.println("point : " + point);
		System.out.println("Player : " + player);
		System.out.println("Score : " + playerposition[player-1]);

		int[][] snakeladder = {
			{21,2},
			{27,15},
			{47,29},
			{56,37},
			{73,46},
			{90,52},
			{99,41},
			{23,42},
			{32,51},
			{61,79},
			{65,84},
			{75,96},
		};

		for(int[] s : snakeladder){
			
			if(playerposition[player-1] == s[0]){
				System.out.println(s[0]>s[1]?"Snake":"Ladder");
				playerposition[player-1] = s[1];
			}
		}
		int x = 97, y = 585;
		int[][] b = {
			{0,0},{0,1},{0,2},{0,3},{0,4},{0,5},{0,6},{0,7},{0,8},{0,9},
			{1,0},{1,1},{1,2},{1,3},{1,4},{1,5},{1,6},{1,7},{1,8},{1,9},
			{2,0},{2,1},{2,2},{2,3},{2,4},{2,5},{2,6},{2,7},{2,8},{2,9},
			{3,0},{3,1},{3,2},{3,3},{3,4},{3,5},{3,6},{3,7},{3,8},{3,9},
			{4,0},{4,1},{4,2},{4,3},{4,4},{4,5},{4,6},{4,7},{4,8},{4,9},
			{5,0},{5,1},{5,2},{5,3},{5,4},{5,5},{5,6},{5,7},{5,8},{5,9},
			{6,0},{6,1},{6,2},{6,3},{6,4},{6,5},{6,6},{6,7},{6,8},{6,9},
			{7,0},{7,1},{7,2},{7,3},{7,4},{7,5},{7,6},{7,7},{7,8},{7,9},
			{8,0},{8,1},{8,2},{8,3},{8,4},{8,5},{8,6},{8,7},{8,8},{8,9},
			{9,0},{9,1},{9,2},{9,3},{9,4},{9,5},{9,6},{9,7},{9,8},{9,9},
		};

		if(player == 1){
			p1score.setText(String.valueOf(playerposition[player-1]));
			int pos = playerposition[player-1];
			int xm =  b[pos-1][1];
			int ym =  b[pos-1][0];
			p1.setBounds((ym+1)%2==0?(x+(60*9))-(xm*60):x+(xm*60) , y-(b[pos-1][0]*60),50,50);
			
		}
		else{
			p2score.setText(String.valueOf(playerposition[player-1]));
			int pos = playerposition[player-1];
			int ym =  b[pos-1][0];
			int xm =  b[pos-1][1];
			p2.setBounds((ym+1)%2==0?(x+(60*9))-(xm*60):x+(xm*60) , y-(b[pos-1][0]*60),50,50);
		}
		if(playerposition[player-1] == 100){ 
			HistoryModel history = new HistoryModel();
			try{
				history.create("(\"Player 1\","+playerposition[player-1]+",\"Player 2\","+playerposition[player-1]+",\"Player "+player+"\")");
			}catch(Exception err){
				System.out.println(err);
			}
			System.out.println("Player " + player + " Win!");
			int confirm = JOptionPane.showConfirmDialog(null, "Player "+player+" Win!", "OK!", JOptionPane.YES_NO_OPTION);
			if(confirm == JOptionPane.YES_OPTION){
				dispose();
				Main frame = new Main();
				frame.setVisible(true);
			}
		}
	}
	
	public Main() {
		setTitle("Runkad"); 
		FrameinMiddle();
        initialize();
	}

	@SuppressWarnings("serial")
	public void initialize(){   
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 720);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 102));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		 lblPlayerName = new JLabel("Playing Player -");
		 lblPlayerName.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		 lblPlayerName.setForeground(new Color(51, 204, 204));
		lblPlayerName.setBounds(724, 67, 132, 26);
		contentPane.add(lblPlayerName);

		 btnDice = new JButton("Roll Dice");
		 btnDice.setFont(new Font("Comic Sans MS", Font.BOLD, 27));
		 btnDice.setForeground(new Color(255, 255, 255));
		 btnDice.setBackground(new Color(0, 0, 51));
		 btnDice.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		btnDice.setBackground(new Color(204, 0, 102));
		 		if(chokka==0){
		 		if(winingPosition==4){
		 			int confirm = JOptionPane.showConfirmDialog(null, "Replay?", "", JOptionPane.YES_NO_OPTION);
					if(confirm == JOptionPane.YES_OPTION){
						dispose();
						Main frame = new Main();
						frame.setVisible(true);
					}
					else{
						setVisible(false); //you can't see me!
						dispose(); //Destroy the JFrame object
						
					}
		 		}
		 		
		 		if(player==2)lblPlayer.setText(String.valueOf(1));
		 		else lblPlayer.setText(String.valueOf(player+1));
		 		}
		 		Dice();                          
		 		if(chokka==0)
		 		{
		 			player++;                    
		 		    if(player==3)player=1; 
		 		}

		 	}
		 });
		 btnDice.setBackground(new Color(0, 0, 51));
		btnDice.setBounds(724, 122, 150, 44);
		contentPane.add(btnDice);


		contentPane.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
                KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "EXIT");
                contentPane.getRootPane().getActionMap().put("EXIT", new AbstractAction(){
                public void actionPerformed(ActionEvent e)
                	{
                		btnDice.doClick();
                	}
                });


		lblP1 = new JLabel("Player 1");
		lblP1.setForeground(new Color(0, 204, 255));
		lblP1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblP1.setBounds(718, 323, 200, 26);
		contentPane.add(lblP1);

		lblDimage = new JLabel(".");
		lblDimage.setHorizontalAlignment(SwingConstants.CENTER);
		lblDimage.setBounds(724, 176, 132, 129);
		contentPane.add(lblDimage);

        p1score = new JLabel("Score");
        p1score.setHorizontalAlignment(SwingConstants.LEFT);
        p1score.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
        p1score.setForeground(new Color(255, 255, 255));
        p1score.setBounds(830, 329, 84, 14);
        contentPane.add(p1score);

        lblP2 = new JLabel("Player 2");
        lblP2.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblP2.setForeground(new Color(255, 204, 0));
        lblP2.setBounds(718, 389, 200, 14);
        contentPane.add(lblP2);

        p2score = new JLabel("Score");
        p2score.setHorizontalAlignment(SwingConstants.LEFT);
        p2score.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
        p2score.setForeground(new Color(255, 255, 255));
        p2score.setBounds(830, 389, 200, 14);
        contentPane.add(p2score);
        lblBoard.setBounds(92, 38, 600, 600);
        contentPane.add(lblBoard);

        lblBoard.setIcon(new ImageIcon(Main.class.getResource("/Image/Board Small 600 600.png")));

		
        p1 = new JLabel("");
        p1.setIcon(new ImageIcon(Main.class.getResource("/Image/player 1.png")));
        p1.setBounds(97, 585, 50, 50);
		p2 = new JLabel("");
        p2.setIcon(new ImageIcon(Main.class.getResource("/Image/player 2.png")));
        p2.setBounds(97, 585, 50, 50);
        contentPane.add(p2);
        contentPane.add(p1);
		contentPane.setComponentZOrder(p1, 0);
		contentPane.setComponentZOrder(p2, 0);

        lblPlayer = new JLabel("1");
        lblPlayer.setHorizontalAlignment(SwingConstants.LEFT);
        lblPlayer.setForeground(new Color(255, 0, 0));
        lblPlayer.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
        lblPlayer.setBounds(858, 67, 62, 26);
        contentPane.add(lblPlayer);

        p1btn = new JLabel("");
        p1btn.setIcon(new ImageIcon(Main.class.getResource("/Image/player 1.png")));
        p1btn.setBounds(984, 312, 50, 50);
        contentPane.add(p1btn);

        label = new JLabel("");
        label.setIcon(new ImageIcon(Main.class.getResource("/Image/player 2.png")));
        label.setBounds(984, 367, 50, 50);
        contentPane.add(label);

        btnRestart = new JButton("Restart??");
        btnRestart.setBackground(new Color(255, 255, 255));
        btnRestart.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnRestart.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		int confirm = JOptionPane.showConfirmDialog(null, "Do you want to Restart?", "Restart!!!", JOptionPane.YES_NO_OPTION);
				if(confirm == JOptionPane.YES_OPTION){
					dispose();
					Main frame = new Main();
					frame.setVisible(true);
				}
        	}
        });
        btnRestart.setBounds(734, 576, 150, 60);
        contentPane.add(btnRestart);
        for(int i=0;i<4;i++){
        	playerposition[i]=0;
        }
	}
	public void FrameinMiddle() {

		Dimension screenSize,frameSize;
		int x,y;
		screenSize=Toolkit.getDefaultToolkit().getScreenSize();
		frameSize=getSize();
		x=(screenSize.width-frameSize.width)/2;
		y=(screenSize.height-frameSize.height)/2;
		setLocation(x, y);
	}
	
}
